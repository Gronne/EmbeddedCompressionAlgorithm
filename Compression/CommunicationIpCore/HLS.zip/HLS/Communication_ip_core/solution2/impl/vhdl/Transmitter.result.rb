$Footmark = "FPGA_Xilinx"
$Description = "by Vivado"


#=== Resource usage ===
$SLICE = "4"
$LUT = "5"
$FF = "13"
$DSP = "0"
$BRAM ="0"
$SRL ="0"
#=== Final timing ===
$TargetCP = "8.000"
$CP = "NA"
