$Footmark = "FPGA_Xilinx"
$Description = "by Vivado"


#=== Resource usage ===
$SLICE = "2"
$LUT = "3"
$FF = "8"
$DSP = "0"
$BRAM ="0"
$SRL ="0"
#=== Final timing ===
$TargetCP = "8.000"
$CP = "NA"
